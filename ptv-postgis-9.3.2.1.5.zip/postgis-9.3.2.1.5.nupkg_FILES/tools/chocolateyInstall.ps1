﻿$packageName = 'postgis-9.3' 
$installerType = 'exe' 
$version = '2.1.5.1'
$url = 'http://download.osgeo.org/postgis/windows/pg93/postgis-bundle-pg93x32-setup-2.1.5-1.exe' 
$url64 = 'http://download.osgeo.org/postgis/windows/pg93/postgis-bundle-pg93x64-setup-2.2.0-1.exe' 
$silentArgs = '/S /USERNAME=postgres /PASSWORD=Ur@n!um824 /PORT=5432'
$validExitCodes = @(0) 

Install-ChocolateyPackage "$packageName" "$installerType" $silentArgs "$url" "$url64"  -validExitCodes $validExitCodes