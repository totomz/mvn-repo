﻿$packageName = 'postgis-93' 
$installerType = 'exe'

$osBitness = Get-ProcessorBits

if ($osBitness -eq 64) {
  $key = 'HKLM:\SOFTWARE\PostgreSQL\Installations\postgresql-x64-9.3'
} else {
  $key = 'HKLM:\SOFTWARE\PostgreSQL\Installations\postgresql-9.3'
}

$installdir = (Get-ItemProperty -Path $key -Name "Base Directory")."Base Directory"

$uninstaller64 = "$installdir\uninstall-postgis-bundle-pg93x64-2.1.5-2.exe"
$uninstaller = "$installdir\uninstall-postgis-bundle-pg93x32-2.1.5-1.exe"


if (Test-Path $uninstaller64) {
    Write-Host "Found PostGIS x64 So Uninstalling"
    Uninstall-ChocolateyPackage $packageName $installerType "/S" $uninstaller64
} elseif (Test-Path $uninstaller) {
    Write-Host "Found PostGIS x32 So Uninstalling"
    Uninstall-ChocolateyPackage $packageName $installerType "/S" $uninstaller
}

if (Test-Path $uninstaller) {
    Remove-Item $uninstaller
    Write-Host "Cleaning Up Uninstaller"
}

if (Test-Path "$installdir\bin\postgisgui") {
    Remove-Item -Recurse -Force "$installdir\bin\postgisgui"
    Write-Host "Cleaning Up Left Over GUI Folder"
}

if (Test-Path "$installdir\pgAdmin III\plugins.d\postgis.shp2pgsql-gui.ini") {
    Remove-Item -Recurse -Force "$installdir\pgAdmin III\plugins.d\postgis.shp2pgsql-gui.ini"
    Write-Host "Cleaning Up Left Over Plugin File"
}